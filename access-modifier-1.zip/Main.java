

public class Main
{
	public static void main(String[] args) {
		System.out.println("Access");
	    
///////////main method only show
	
	}
	
	private void methodone() {
	   System.out.println("method 1");
	}   
	
}
