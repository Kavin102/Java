
public class Main
{
	public static void main(String[] args) {
	System.out.println("switch");
//loop types = for loop , while loop , do while , for each loop 
//for loop 

 for ( int initial = 12 ; initial > 0 ; initial ++   ){


  System.out.println("hi bye");




}



	}
}
