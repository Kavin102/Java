
public class Main
{
	public static void main(String[] args) {
		System.out.println("math method in java");
   
   int Number = 125;
   float Number1 = 101.13f;
    
     System.out.println(Math.negateExact(Number));
                        //   abs , ceil , floor , max , min , exp etc....
                        


	}
}
