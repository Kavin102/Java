
public class Main
{
	public static void main(String[] args) {
	
		System.out.println("kavin");
	   byte Number1 = 10;
	   byte Number2 =111;
	   
	
       System.out.println(Number1 * Number2);	
	
	                              //divide or add or sub or percantage etc....
	   
	
	
	
	
	
	}
}


