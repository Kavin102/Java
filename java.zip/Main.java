

public class Main
{
    public static void main (String[] args) {
        
     System.out.println("hello world");
    
     //5 =0,1,2,3,4
     int [] numbers = new int[]{10,11,12,13,15};
     // numbers[0] = 10;
     // numbers[1] = 11;
     
     System.out.println(numbers);
    }
}