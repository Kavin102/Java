
public class Main
{
	public static void main(String[] args) {
	
		System.out.println("Achu");
	   byte Number1 = 10;
	   int Number2 = 110;
	   
	   int Number3 = Number2 + Number1;
	  // only integer 
	  System.out.println("sout tab....");
	  Number2 = Number2 + 21;
	 //short cut   +=
	  Number2 *= 21;
	  
	  int Number4 = 9-9 + 10 * 9 / 2 /1 % 5 / 6;
                           // bodmas  up
      int Number5 = 2 *+ 1;
    
    
    

     
       System.out.println(Number1+Number2+Number3+Number4+Number5);	
    
     	
	    // == can check the Number1 and Number2 equal or not ??
       // != 	
	 
	
	
	
	
	
	
	}
	
	
}
