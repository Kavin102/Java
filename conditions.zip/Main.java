import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
		System.out.println("conditions (if,else if , if) ");
	
	//if condition  if = key word
	
	int pen = 10;
	int specialpen = 40;
    int cost ;
     Scanner input = new Scanner(System.in);
      cost = input.nextInt();
      if (cost > specialpen){
      System.out.println("you can buy the special pen");
      }
      else if(cost > pen){
          System.out.println("you can buy the pen");
          System.out.println("you have " + cost);
      }
         System.out.println("you have less money to buy the pen");
      }
      
	}

	