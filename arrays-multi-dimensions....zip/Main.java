
public class Main
{
	public static void main(String[] args) {
	
		System.out.println("hi bye");
	    int NumberOne = 1000;
	    int ageofperson = 25;
	    //descrptive name 
	    int numbers[] = { 1 , 2 , 3 };     
	    int numbersof2Dim[][] = { {1,2 } , { 1, 3} };
	//2dim means dimension....
	   
        byte number = 5;	
	    number = 10;
     System.out.println(number);
	    
	    final int ageofperson1 = 18;
	     	    //same variable doesnt works...for example 8th step age of person and 18 th step ageofperson1....
        //ageofperson1 = 21	 *notes
  	    
	}
	
}



