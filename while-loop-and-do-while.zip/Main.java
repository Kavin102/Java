
public class Main
{
	public static void main(String[] args) {
		System.out.println("bye World");

    int Number = 2;
    while(Number > 0){




    System.out.println("while loop");

   
    int number1 = 1 ;
  // do loop
  do{
    
    System.out.println("do while loop");
    number1 -- ;
   }while (number1 > 10);


  }

} 

}



