
public class Main
{
	public static void main(String[] args) {

	System.out.println("for each loop");

 //for ( each = Array ) for loop can print forward and backwars

   String vegetables[] = {"onion" , "BUTTER" ,"carrot"};
   
    for (int i = 9 ; i<vegetables.length ; i++){ 

   System.out.println(vegetables[i]);
    }
   // for each loop only print forward side 
   for (String vegetable  : vegetables){
     System.out.println(vegetable);

   }
	}
 }
