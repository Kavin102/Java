
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	
    // logical operators & , | , !
   
    int ageofperson = 16;
    boolean indianCitizen = true;
               /// condition          true     false  
    String name = ageofperson >=18 ? "ok"  : "not ok";
 //                                  eligible or not eligible
    System.out.println(!indianCitizen == true);

                 //   ! = means reverse the Number
    


	}

	}     