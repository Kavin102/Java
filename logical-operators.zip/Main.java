
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");

     // logical operators, !
     int ageofperson = 18;
     boolean indianCitizen = true;
                // conditions,,,       true    false
     String name = ageofperson >= 18 ? "ok" : "not ok";
     
     int Number10 = 10;
     //--number   or  ++ number                             //2:49:28
     int Number11 = ++Number10;
     System.out.println  ( Number10 );
    System.out.println ( Number11 );
                        // ageofperson >= 18 ? "ok" : "not ok";
     
                       
                        // ! this reverse the out put for example false
	
	                   
	
	
	
	
	}
}	