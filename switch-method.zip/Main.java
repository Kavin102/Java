import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	
	// switch
	
	int Number = 33;
	String name = "kavin";
	
	Scanner input = new Scanner(System.in);
	name = input.nextLine();
	
	switch (name){
	   
	    case "abcde" :   //this is case
	System.out.println("hi," + name);
	   break;
	  
		    case "kavin" :   //this is case
	System.out.println("hi," + name);
	   break;
	   
		    case "name" :   //this is case
	System.out.println("hi," + name);
	   break;
	   
		    case "efghi" :   //this is case
	System.out.println("hi," + name);
	   break;
	   
	   
	   	    case "dfssrhg" :   //this is case
	System.out.println("hi," + name);
	   break;
	   default :
	    System.out.println("your name is not in list");
	   
	}
	    
	}
	
}
