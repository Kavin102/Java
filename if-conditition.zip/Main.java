import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
		System.out.println("conditions (if,else if , if) ");
	
	//if condition  if = key word
	int cafe = 10;
	int cost = 1;
	if (cost > cafe){
	 
	  Scanner input = new Scanner(System.in);
	 
	 System.out.println("you can buy the cafe");
	
	}
	else{
	     System.out.println("you have less money to buy the cafe");
	
	}
	
	
	
	
	}
	
}

