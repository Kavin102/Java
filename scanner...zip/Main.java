import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Scanner");
       	
     String  name ;
	    /// BASIC 
    Scanner input = new Scanner(System.in);
                    
            // above lines are important//
    System.out.println("Enter a name:");
     name = input.next();
  
    System.out.println("hi ,"+ name);
	    
	}
	
}

